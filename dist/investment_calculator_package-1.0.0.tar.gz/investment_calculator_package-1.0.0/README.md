# InvestmentCalculatorPackage
a python package to calculate investment returns
